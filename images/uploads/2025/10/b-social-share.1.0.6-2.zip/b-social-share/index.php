<?php
// Silent is golden